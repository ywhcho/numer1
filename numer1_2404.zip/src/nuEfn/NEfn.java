package nuEfn;

import cuti.NCu;

public class NEfn {
	public static String[] be00Ejl_kArray1(String tmSent) {
		int tk_Ejeol = 0;
		String s9 = "";
		char ch = 0, ch_p1 = 0, ch_m1 = 0; //, ch_m2=0; //사용 할 일 없음:
		int length_Sen = tmSent.length();
		char[] ch_arSen = tmSent.toCharArray();
		String arEjeol90[] = new String[90];

		for (int i = 0; i < length_Sen; i++) {
			if (i> 0)
				ch_m1 = ch;

			if (i<= length_Sen - 2) {
				if (i==0) {
					ch= ch_arSen[i];
					ch= fReplaceChar(ch);
				} else 
					ch= ch_p1;
				//
				ch_p1 = ch_arSen[i + 1];
				ch_p1= fReplaceChar(ch_p1);
			} else {
				ch_p1 = 0;
				ch = ch_arSen[i];
				ch= fReplaceChar(ch);
			}

			if (ch<48) {  //48='0'
				if (ch == ' ') {    //asc=32
					if (ch_m1== ' ' || ch_p1== '.' || ch_p1== ',') {
					} else if (s9.length()> 0) {
						tk_Ejeol++;
						arEjeol90[tk_Ejeol] = s9;
						s9 = "";
					} 
				} else if (i== length_Sen- 1) {
					s9 = s9 + ch;
					tk_Ejeol++;
					arEjeol90[tk_Ejeol] = s9;
					s9 = "";	
				} else if (ch==',') { // 20201104일:이전일자 참조:
					if (ch_p1>=44032 && ch_p1<=55203) { 
						s9 = s9 + ch;
						tk_Ejeol++;
						arEjeol90[tk_Ejeol] = s9;
						s9 = "";
					} else {
						s9 = s9 + ch;
					}
				} else if (ch == '#') {  //asc=35
					if (ch_m1 != ' ' && ch_p1 != ' ' && i > 0) {
						if (ch == ch_m1 || ch_m1 == '[' || ch_m1 == '{') {
							s9 = s9 + ch;
						} else { // if (s9.length() > 0) {
							tk_Ejeol++;
							arEjeol90[tk_Ejeol] = s9;
							s9 = "#";
						}
					} else
						s9 = s9 + ch;	
				} else {
					s9 = s9 + ch;
				}
			} else if (i== length_Sen- 1) {
				s9 = s9 + ch;
				tk_Ejeol++;
				arEjeol90[tk_Ejeol] = s9;
				s9 = "";	
			} else {
				s9 = s9 + ch;
			}

			if (tk_Ejeol > 95) {
				System.out.println("tk_EJeol이 95을 초과하여 여기까지만 합니다");
				break;
			}
		} //for 

		if (tk_Ejeol == 0) {
			s9 = tmSent;
			tk_Ejeol++;
			arEjeol90[tk_Ejeol] = s9;
		}
		arEjeol90[0] = Integer.toString(tk_Ejeol);
		return arEjeol90;
	} // be00Ejl_kArray1()_end
	
	public static Character fReplaceChar(char tmCh) {
		char ch2= tmCh;
		if (tmCh<12296) {  //12296=〈  //ㄱ:12593,ㅤ(bln):12644 	//':39
			if (tmCh==9 || tmCh==160) { //tab(9) ->bln, 160(유령코드:&nbsp;)->32 : 생각하고 있어
				ch2= 32; //bln
			} else if (tmCh=='–') { //–: 8211
				ch2= '-';			//-:45
		 	} else if (tmCh=='•') {	 //•: 8226
		 		ch2 = '·';			 //·: 183
		 	} else if (tmCh==8764) { //∼:8674,
				ch2= 126;			
		 	}						 //〃: 12291
		} else if (tmCh<12644) { // // 'ㅤ'=12644), ㅥ=12645 	
		 	if (tmCh=='〈') { //〈:12296
		 		ch2= '<';
		 	} else if (tmCh=='〉') { // 〈:12297
		 		ch2= '>';
		 	} else if (tmCh=='《' ) { //《: 12298, 65308
		 		ch2='<';			//<:60
		 	} else if (tmCh=='》') {	//》:12299
		 		ch2='>';			//>:62
		 	} else if (tmCh== '【') {	//【:12304
		 		ch2='[';			//[:91
		 	} else if (tmCh== '】') {  //】:12305
		 		ch2=']';			//]:93
		 	//} else if (tmCh== 'ㅡ') {	//12641
		 	//	ch2='-';
		 	} else if (tmCh == 'ㅣ') {  // 12643
				ch2 = '|';	//124	
			} 	
		} else if (tmCh>65000) {		//55203 =힣
			if (tmCh== '＞') {	//65310
				ch2= '>';
			} else if (tmCh== '＜') { //65308
				ch2= '<';
			} else if (tmCh == '｜') {  //｜:65372  //｛= 65371,  ｝=65373 
				ch2 = '|';	//124
			} else if (tmCh=='ｍ') { //ｍ:65357
				ch2= 'm';	
			} else if (tmCh=='～') { // ～:65374
				ch2= 126; //'~' 
			} else if (tmCh=='，') { //65292
				ch2= ',';
			}	
		}
		return ch2;
	}
	
	public static String fPick1ChMarkAsS1(char tmC1) {	//가:=44032, 힣=55203
		String tpRS1 = ""; // space:40 //$:36 %:37 &:38
		if (tmC1 < 128) { // 128:del
			if (tmC1 < 48) { // 48='0'
				if (tmC1 == '\"') { // 34 //<:60, =:61 >:62,`:96
					tpRS1 = "A"; // 'DQUO' // @:64, _:95,|:124
				} else if (tmC1 == '\'') { // 39 :'
					tpRS1 = "B"; // 'SQUO'
				} else if (tmC1 == ',') { // 44
					tpRS1 = "C"; // 'COMM'
				} else if (tmC1 == '.') { // 46
					tpRS1 = "D"; // Dot:PERI
				} else if (tmC1 == '!') { // 33
					tpRS1 = "F"; // 'EXCL'
				} else if (tmC1 == '(') { // 40
					tpRS1 = "H"; // 'EXCL'
				} else if (tmC1 == ')') { // 41
					tpRS1 = "I";
				} else if (tmC1 == '&') { // 38
					tpRS1 = "R";
				} else if (tmC1 == '#') { // 35
					tpRS1 = "S";
				} else if (tmC1 == '-') { // 45
					tpRS1 = "K";
				} else if (tmC1 == '/') { // 47 
					tpRS1 = "L";
				} else if (tmC1 == '+') { // 43
					tpRS1 = "M";
				} else if (tmC1 == '*') { // 42
					tpRS1 = "N";
				} else if (tmC1 == '$') { // 44
					tpRS1 = "N";
				} else {
					tpRS1 = "";
				}
			} else if (tmC1 < 58) {
				tpRS1 = ""; // Number (58=':')
			} else { // >=59
				if (tmC1 == '[') { // 91
					tpRS1 = "B"; // 'SQUO'
				} else if (tmC1 == ']') { // 93 ]
					tpRS1 = "B"; // 'SQUO'
				} else if (tmC1 == '?') { // 63
					tpRS1 = "E"; // 'QUES'
				} else if (tmC1 == ':') { // 58 'COLO
					tpRS1 = "G";
				} else if (tmC1 == '{') { // 123
					tpRS1 = "A"; // 'DQUO'
				} else if (tmC1 == '}') { // 125:
					tpRS1 = "A"; // 'DQUO'
				} else if (tmC1 == '~') { // 126
					tpRS1 = "J";
				} else if (tmC1 == '^') { // 94
					tpRS1 = "O";
				} else if (tmC1 == ';') { // 59
					tpRS1 = "Q";
				} else if (tmC1 == '_') { // 95
					tpRS1 = "Z";
				} else if (tmC1 == '|') { // 124
					tpRS1 = "T";
				} else if (tmC1 == '<') { // 60
					tpRS1 = "U";	
				} else if (tmC1 == '>') { // 62
					tpRS1 = "V";
				} else if (tmC1 == '=') { // 61
					tpRS1 = "W";
				//} else if (tmC1 == '@') { // 64
				//	tpRS1 = "Y";	
				} else if (tmC1 == '\\') { // '\'92
					tpRS1 = "X";
				} else {
					tpRS1 = "";
				}
			}
		} else {
			if (tmC1 == '“') { 			//asc=8220: ->34:}
				tpRS1 = "A"; 	//'DQUO'
			} else if (tmC1 == '”') { 	//asc=8221: ->34:{
				tpRS1 = "A"; // 'DQUO'
			} else if (tmC1 == '‘') { 	//asc=8216: ->39 [
				tpRS1 = "B"; // 'SQUO'
			} else if (tmC1 == '’') { 	//asc=8217: ->39 ]
				tpRS1 = "B"; // 'SQUO'
			} else if (tmC1 == '·') { 	//asc=183:
				tpRS1 = "P";
			} else if (tmC1 == 'ㆍ') {	//asc=12685:
				tpRS1 = "P";
			} else if (tmC1 == 'ㅣ' || tmC1 == '｜') { //asc=12643, asc=65372:
				tpRS1 = "T";
			} else if (tmC1 == '…') {		//asc= 8230
				tpRS1 = "P"; //old:Y
			} else {
				tpRS1 = "";
			}
		} 
		return tpRS1;
	}
	
	public static String fPickKStrNumber(String tmiEjeol, String tmEjeol_m1, String tmStrNum1) { //, String tmPt1) {	//int tmi, 
		String[] teStrNum = new String[40];
		teStrNum[0] = ""; 
		boolean[] tfA1Num = new boolean[40];
		String tmpResu= "", S1= "", S2= "", S1_ini1= "", tmpNStr_f = "";	//tmpStrN = "", 
		int tl_Ejlth = tmStrNum1.length(), k_Num = 0, i_StrNumf = 0;
		boolean tfNumBf = false; 

		char[] ch_arSNum1 = tmStrNum1.toCharArray();
		char ch_SNum=0, chSN_p1=0, chSN_p2=0, chSN_m1=0;
		String tpS1p1 = "", tmpS1m1="", tmpS2p1="", tpRepo= ""; //, tpS1m1=""; //,tpS1m2="",
		////////////////////////
		/////////// 동일 사용 공간 __start_
		int i = 0;
		while (i < tl_Ejlth) {
			tpS1p1 = "";
			if (i < tl_Ejlth - 1) {
				chSN_p1= ch_arSNum1[i+1];
				tpS1p1 = Character.toString(chSN_p1); //tmStrNum1.substring(i + 1, i + 2); // 너의 나이는 열두살이다 //참조: (Copy(tmpStr1,i+2,2)='살')
				tmpS2p1=""; 
				if (i<tl_Ejlth-2) {
					chSN_p2= ch_arSNum1[i+2];
					tmpS2p1 = Character.toString(chSN_p1)+ chSN_p2; //tmStrNum1.substring(i+1,i+3); //
				}	
			}
			//
			chSN_m1= ch_SNum; 
			tmpS1m1= S1;
			ch_SNum= ch_arSNum1[i];
			S1 = Character.toString(ch_SNum);
			S2 = "";
			if (i < tl_Ejlth - 1)
				S2 = S1 + chSN_p1; 

			if (i>37) {
				System.out.println("자릿수가 37을 넘어가서 중단합니다. tmStrNum1="+tmStrNum1+", i="+i+" , tpS1p1="+tpS1p1);
				break;
			} else if (S1.length() > 0) {
				if (S2.equals("하나") || S2.equals("다섯") || S2.equals("여섯") || S2.equals("일곱") || S2.equals("여덟")
					|| S2.equals("아홉") || S2.equals("스물") // (S2.equals("스무") or
					|| S2.equals("서른") || S2.equals("마흔") || S2.equals("시흔") || S2.equals("예순") || S2.equals("일흔")
					|| S2.equals("여든") || S2.equals("아흔") || S2.equals("설흔")) {
					k_Num = k_Num + 1;
					teStrNum[k_Num] = S2;
					//tmpStrN= tmpStrN + S2;
					i_StrNumf = i_StrNumf + 2;
					tfNumBf = false;
					tfA1Num[k_Num] = false;
					i++; // cy180428://S2TF=true;
					tpRepo = tpRepo + " : pre_fKStrNum_1  1_5_90_9"; // tmpStrN=" + tmpStrN;
				} else if (S2.equals("스무")) {	//cy230904Ap
					if (NCu.fCopyN(tmpS2p1,2,1).equals("살") || NCu.fCopyN(tmpS2p1,2,1).equals("해")) {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S2;
						i_StrNumf = i_StrNumf + 2;
						//tmpStrN= tmpStrN + S1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fKStrNum_1a 살,해/S2="+S2+", tmpS2p1="+tmpS2p1; 
						break;
					}	
				} else if (S1.equals("이")) { // 백십이다 //백일이다 //백오명이다
					String StrN_m1 = teStrNum[k_Num];
					String ckStrBf = "";
					if (StrN_m1.length() > 0)
						ckStrBf = fPickKStrDotNum(tmiEjeol, tmEjeol_m1, StrN_m1);	//1, 
					///
					if (tpS1p1.equals("것") || tpS1p1.equals("다") || tpS1p1.equals("냐") || tpS1p1.equals("었")) {
						tpRepo = tpRepo + " : pre_fKStrNum_2 /이"; 
						break;
					} else if (ckStrBf.length() > 0) { // equals("영")) {
						tpRepo = tpRepo + " : pre_fKStrNum_3 /이 bln"; 
						break;
					} else {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fKStrNum_4 이/"; 
					}
				} else if (S1.equals("유")) { // 유월이다 //참조: 시월 어느 날
					if (tpS1p1.equals("월")) {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fKStrNum_5a2 유/";
						break;
					} else {
						tpRepo = tpRepo + " : pre_fKStrNum_5a2 유/"; 
						break;
					}
				} else if (S1.equals("사")) {
					if (tmpS1m1.equals("두") || tmpS1m1.equals("세") || tmpS1m1.equals("네")) { //두사람이다
							tpRepo = tpRepo + " : pre_fKStrNum_5a";
					} else if (tmpS2p1.equals("나이")) {		
					} else {		
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
					}	
					tpRepo = tpRepo + " : pre_fKStrNum_5b"; 
				} else if (S1.equals("삼") || S1.equals("오") || S1.equals("육") || S1.equals("칠")
					|| S1.equals("팔") || S1.equals("구") || S1.equals("둘") || S1.equals("셋") || S1.equals("넷")) {
					k_Num = k_Num + 1;
					teStrNum[k_Num] = S1;
					i_StrNumf = i_StrNumf + 1;
					tfNumBf = false;
					tfA1Num[k_Num] = false;
					tpRepo = tpRepo + " : pre_fKStrNum_5"; 
				} else if (S1.equals("만")) {
					k_Num = k_Num + 1;
					teStrNum[k_Num] = S1;
					i_StrNumf = i_StrNumf + 1;
					tfNumBf = false;
					tfA1Num[k_Num] = false;
					tpRepo = tpRepo + " : pre_fKStrNum_6";
				} else if (S1.equals("열")) {  //3열종대로
					if (chSN_m1>='0' || chSN_m1<= '9') {
						
					} else {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
					}	
					tpRepo = tpRepo + " : pre_fKStrNum_6a";		
				} else if (S1.equals("십") || S1.equals("백") || S1.equals("천") || S1.equals("억") 
					|| S1.equals("쉰")) {
					k_Num = k_Num + 1;
					teStrNum[k_Num] = S1;
					i_StrNumf = i_StrNumf + 1;
					tfNumBf = false;
					tfA1Num[k_Num] = false;
					tpRepo = tpRepo + " : pre_fKStrNum_6c";
				} else if (S1.equals("시")) { // 시월 어느 날
					if (tpS1p1.equals("월")) {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						//tmpStrN= tmpStrN + S1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fKStrNum_6b1 시(십)"; // tmpStrN=" + tmpStrN;
						break;
					} else {
						tpRepo = tpRepo + " : pre_fKStrNum_6b2 시(십)"; // tmpStrN=" + tmpStrN; // 
						break;
					}	
				} else if (S1.equals("일")) { // 팔월십오일은 무슨 날이냐
					int i_mth = 0;
					int jlth = tmiEjeol.length();
					if (tpS1p1.equals("일") || tpS1p1.equals("월") || tpS1p1.equals("년")) {
					} else {
						for (int ei = jlth; ei >= 1; ei--) {
							if (NCu.fCopyN(tmiEjeol, ei - 1, 1).equals("월")) {
								i_mth = ei;
								break;
							}
						}
					}	
					// 오월 삼십일이다
					String Str_m1 = teStrNum[k_Num];
					String ckStrBf = "";
					if (Str_m1.length() > 0)
						ckStrBf = fPickKStrDotNum(tmiEjeol, tmEjeol_m1, Str_m1);	//1, 

					if (ckStrBf.length() > 0) {
						tpRepo = tpRepo + " : pre_fKStrNum_8 /이 bln"; //tmpStrN=" + tmpStrN;
						break;
						// 오일은 좋은 날이다
					} else if (i_mth > 0 || NCu.fRightN(tmEjeol_m1, 1).equals("월")) { //teEjeolm1:일월 삼십일입니다
						if (tpS1p1.equals("일") || tpS1p1.equals("월") || tpS1p1.equals("년")) { // 팔월십오일은 광복절이다
							k_Num = k_Num + 1;
							teStrNum[k_Num] = S1;
							i_StrNumf = i_StrNumf + 1;
							tfNumBf = false;
							tfA1Num[k_Num] = false;
							tpRepo = tpRepo + " : pre_fKStrNum_10b 일/월1/"; // tmpStrN=" + tmpStrN + "/일";
						} else {
							tpRepo = tpRepo + " : pre_fKStrNum_11b 일/월1/"+S1+"/"; // tmpStrN=" + tmpStrN + "일";
							break;
						}
					} else if (tpS1p1.equals("이")) {
						tpRepo = tpRepo + " : pre_fKStrNum_13"; 
						break;
					} else if (teStrNum[k_Num].equals("한") || teStrNum[k_Num].equals("두")
							|| teStrNum[k_Num].equals("세")) {
						tpRepo = tpRepo + " : pre_fKStrNum_15b 일/월/"; // tmpStrN=" + tmpStrN;
						break;
					} else {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tpRepo = tpRepo + " : pre_fKStrNum_17b 일/월/"; // tmpStrN=" + tmpStrN;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
					}
					System.out.println("Efn_fArkSum_일 i="+i+", tmiEjeol="+tmiEjeol+", fCopyN(tmiEjeol,i+1,1)="+NCu.fCopyN(tmiEjeol,i+1,1));
				} else if (S1.equals("조")) {
					if (tpS1p1.equals("금")) {
						
					} else {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false; //
					}
					
				} else if (S1.equals("경")) {
					if (tpS1p1.equals("치")) {
						
					} else { // if (i>0) {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false; //
					}	
				} else if (S1.equals("세")) {	//Ar2KStrDotNum에는 안 들어감:
					String Str_m1 = teStrNum[k_Num];
					String ckStrBf = "";
					if (Str_m1.length() > 0)
						ckStrBf = fPickKStrDotNum(tmiEjeol, tmEjeol_m1, Str_m1);	//1, 
					if (ckStrBf.length() > 0) { // equals("영")) {
						tpRepo = tpRepo + " : pre_fKStrNum_18a/ bln"; // || tpS1p1.equals("대") //tmpStrN=" + tmpStrN;
					} else if (tpS1p1.equals("개") || tpS1p1.equals("달") || tpS1p1.equals("살")
						|| tpS1p1.equals("명") || tmpS2p1.equals("마리") || tmpS2p1.equals("군데") || tmpS2p1.equals("사람")) { // ||
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fKStrNum_18c  tpS1p1=" + tpS1p1; //+ ", tmpStrN=" + tmpStrN;
					} else {
						tpRepo = tpRepo+" : pre_fKStrNum_18e blnf tpS1p1="+tpS1p1;
						break;
					}
					tfNumBf = false;	
				} else if (S1.equals("한") || S1.equals("두") || S1.equals("네")) { //|| S1.equals("세")
					String Str_m1 = teStrNum[k_Num];
					String ckStrBf = "";
					if (Str_m1.length() > 0)
						ckStrBf = fPickKStrDotNum(tmiEjeol, tmEjeol_m1, Str_m1);	//1, 
					if (ckStrBf.length() > 0) { // equals("영")) {
						tpRepo = tpRepo + " : pre_fKStrNum_19a/ bln"; // tmpStrN=" + tmpStrN;
					} else { 
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fKStrNum_19b  tpS1p1=" + tpS1p1; //+ ", tmpStrN=" + tmpStrN;
					}
					tfNumBf = false;
				} else if (S1.equals("1") || S1.equals("2") || S1.equals("3") || S1.equals("4") || S1.equals("5")
						|| S1.equals("6") || S1.equals("7") || S1.equals("8") || S1.equals("9") || S1.equals("0")) {
					if (tfNumBf == false) {
						k_Num = k_Num + 1;
						tfNumBf = true;
						teStrNum[k_Num] = S1;
					} else
						teStrNum[k_Num] = teStrNum[k_Num] + S1;
					//
					i_StrNumf = i_StrNumf + 1;
					tfA1Num[k_Num] = true;
				} else {
					break;
				}
			} // if (S1.length()>0)
				////
			i++;
		} // while //for (int i=0; i<tl_Ejlth; i++) {
			//////
		tmpNStr_f = "";
		String tmpStrN_m1 = "";
		String tmpStrNp1 = "", tmpStrNp2 = "", tmpStrNp3 = "", SNp1 = "";
		for (i = k_Num; i >= 1; i--) { //// for i = k_Num downto 1 do
			S1 = "";
			S2 = "";
			tmpStrNp1 = "";
			tmpStrNp2 = "";
			tmpStrNp3 = "";
			SNp1 = "";
			int tNp1 = 0;
			if (i < k_Num) {
				tmpStrNp1 = teStrNum[i + 1]; // ok:cy180427
				if (i < k_Num - 1)
					tmpStrNp2 = teStrNum[i + 2];
				if (i < k_Num - 2)
					tmpStrNp3 = teStrNum[i + 3];
				SNp1 = fPickKStrDotNum(tmiEjeol, tmEjeol_m1, tmpStrNp1);	//1, 
				if (SNp1.length() > 0)
					tNp1 = Integer.parseInt(NCu.fRightN(SNp1, 1));
			}
			//
			tmpStrN_m1 = "";
			if (i > 1) {
				tmpStrN_m1 = teStrNum[i - 1];
			}

			if (tfA1Num[i] == true) {
				S1 = teStrNum[i];
			} else if (teStrNum[i].length() == 1) {
				S1 = teStrNum[i];
			} else if (teStrNum[i].length() == 2) 
				S2 = teStrNum[i];
			//
			if (tfA1Num[i] == true) {
				tmpNStr_f = S1 + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_21 일/" + tmpNStr_f + ", tmpNStr_f=" + tmpNStr_f;
			} else if (S1.equals("일")) { // 검토: 이십일일이다
				tmpNStr_f = "1" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_25 일/" + tmpNStr_f;
			} else if (S1.equals("이")) {
				tmpNStr_f = "2" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_27 이/" + tmpNStr_f;
			} else if (S1.equals("삼")) {
				tmpNStr_f = "3" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_29 삼/" + tmpNStr_f;
			} else if (S1.equals("사") || S1.equals("네")) {
				tmpNStr_f = "4" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_31 사/" + tmpNStr_f;
			} else if (S1.equals("오")) {
				tmpNStr_f = "5" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_33 오/" + tmpNStr_f;
			} else if (S1.equals("육")) {
				tmpNStr_f = "6" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_35 육/" + tmpNStr_f;
			} else if (S1.equals("유")) {
				tmpNStr_f = "6" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_36 유(육)/" + tmpNStr_f;		
			} else if (S1.equals("칠")) {
				tmpNStr_f = "7" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_37 칠/" + tmpNStr_f;
			} else if (S1.equals("팔")) {
				tmpNStr_f = "8" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_39 팔/" + tmpNStr_f;
			} else if (S1.equals("구")) {
				tmpNStr_f = "9" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_41 구/" + tmpNStr_f;
			} else if (S1.equals("십")) {
				if (i == 1 || tmpStrN_m1.equals("경") || tmpStrN_m1.equals("조") || tmpStrN_m1.equals("억")
					|| tmpStrN_m1.equals("만") || tmpStrN_m1.equals("천") || tmpStrN_m1.equals("백")) {
					S1_ini1 = "1";
				} else
					S1_ini1 = "";
				/////////////////////////////////////////////////////////////////////
				if (k_Num == 1) {
					tmpNStr_f = "10" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_51 십/" + tmpNStr_f;
				} else if (i == k_Num) {
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_53 십/" + tmpNStr_f;
				} else if (teStrNum[i + 1].equals("만") || teStrNum[i + 1].equals("억") || teStrNum[i + 1].equals("조")
					|| teStrNum[i + 1].equals("경")) {
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_55 십/" + tmpNStr_f;
				} else {
					tmpNStr_f = S1_ini1 + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_58 십/" + tmpNStr_f;
				}
			} else if (S1.equals("시")) {
				tmpNStr_f = "10" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum_60 시(십)/" + tmpNStr_f;	
			} else if (S1.equals("백")) {
				if (i == 1 || tmpStrN_m1.equals("경") || tmpStrN_m1.equals("조") || tmpStrN_m1.equals("억")
					|| tmpStrN_m1.equals("만") || tmpStrN_m1.equals("천")) {
					S1_ini1 = "1";
				} else
					S1_ini1 = "";
				///
				if (k_Num == 1) {
					tmpNStr_f = "100" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_101 백/" + tmpNStr_f;
				} else if (i == k_Num) {
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_103 백/" + tmpNStr_f;
				} else if (tmpStrNp1.equals("만") || tmpStrNp1.equals("억") || tmpStrNp1.equals("조")
						|| tmpStrNp1.equals("경")) {
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_105 백/" + tmpNStr_f;
				} else if (tmpStrNp1.equals("십") || tmpStrNp2.equals("십")) {
					// 백십명이다: ok180428
					tmpNStr_f = S1_ini1 + tmpNStr_f; // "0"+
					tpRepo = tpRepo + " :fnPickKSNum_109 백/" + tmpNStr_f;
				} else if (tmpStrNp1.equals("열") || tmpStrNp1.equals("쉰") || tmpStrNp1.equals("스물")
					|| tmpStrNp1.equals("서른") || tmpStrNp1.equals("마흔") || tmpStrNp1.equals("시흔")
					|| tmpStrNp1.equals("예순") || tmpStrNp1.equals("일흔") || tmpStrNp1.equals("여든")
					|| tmpStrNp1.equals("아흔")) {
					// 백서른살입니다
					tmpNStr_f = S1_ini1 + tmpNStr_f; // "0"+
					tpRepo = tpRepo + " :fnPickKSNum_111 백/" + tmpNStr_f;
					System.out.println("백_110 tmpStrNp1=" + tmpStrNp1 + ", tmpNStr_f=" + tmpNStr_f + ", repo=" + tpRepo);
				} else if (tmpStrNp1.equals("스무") || tmpStrNp1.equals("설흔")) { //cy230904Ap
					tmpNStr_f = S1_ini1 + tmpNStr_f; // "0"+
					tpRepo = tpRepo + " :fnPickKSNum_112 백/" + tmpNStr_f;
				} else if (tNp1 > 0 && tNp1 <= 9) {
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f; 
					tpRepo = tpRepo + " :fKStrNum_113 /백 " + tmpNStr_f + ", tNp1=" + tNp1;
				} else {
					// 백육명이다 //백10명이다:ok180418
					tmpNStr_f = S1_ini1 + NCu.fRightN("0" + tmpNStr_f, 2); 
					tpRepo = tpRepo + " :fnPickKSNum_115 백/" + tmpNStr_f + ", S1_ini1=" + S1_ini1;
				}
				//////////////////////////////////////////////////////
			} else if (S1.equals("천")) {
				if (i == 1 || tmpStrN_m1.equals("경") || tmpStrN_m1.equals("조") || tmpStrN_m1.equals("억")
					|| tmpStrN_m1.equals("만")) {
					S1_ini1 = "1";
				} else
					S1_ini1 = "";
				////////////////////////////
				if (k_Num == 1) {
					tmpNStr_f = "1000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_131: " + tmpNStr_f;
				} else if (i == k_Num) {
					tmpNStr_f = S1_ini1 + "000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_133: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("만") || tmpStrNp1.equals("억") || tmpStrNp1.equals("조")
					|| tmpStrNp1.equals("경")) {
					// 오천만명이다:ok180428
					tmpNStr_f = S1_ini1 + "000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_135: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("백") || tmpStrNp2.equals("백")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_137: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("십") || tmpStrNp2.equals("십") || tmpStrNp1.equals("열")) { // + tmpStrNp2
					// 천십명이다: ok180428
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_139 /천 " + tmpNStr_f;
				} else if (tmpStrNp1.equals("열") || tmpStrNp1.equals("쉰") || tmpStrNp1.equals("스물")
					|| tmpStrNp1.equals("서른") || tmpStrNp1.equals("마흔") || tmpStrNp1.equals("시흔")
					|| tmpStrNp1.equals("예순") || tmpStrNp1.equals("일흔") || tmpStrNp1.equals("여든")
					|| tmpStrNp1.equals("아흔")) {
					// 백서른살입니다
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_141 /천 " + tmpNStr_f;
				} else if (tmpStrNp1.equals("스무") || tmpStrNp1.equals("설흔")) { //cy230904Ap
					tmpNStr_f = S1_ini1 + "0"+tmpNStr_f;
					tpRepo = tpRepo + " :fnPickKSNum_142 천/" + tmpNStr_f;	
				} else if (tNp1 > 0 && tNp1 <= 9) {
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f; // S1_ini1+Cuti.fRightN("00"+tmpNStr_f,3);
					tpRepo = tpRepo + " :fKStrNum_143 /천 " + tmpNStr_f + ", tNp1=" + tNp1;
				} else { // 천육명이다 : ok:180428
					tmpNStr_f = S1_ini1 + NCu.fRightN("00" + tmpNStr_f, 3);
					tpRepo = tpRepo + " :fKStrNum_145 천 " + tmpNStr_f + ", tNp1=" + tNp1;
				}
			} else if (S1.equals("만")) {
				if (i == 1 || tmpStrN_m1.equals("경") || tmpStrN_m1.equals("조") || tmpStrN_m1.equals("억")) {
					S1_ini1 = "1";
				} else
					S1_ini1 = "";
				////
				if (k_Num == 1) {
					tmpNStr_f = "10000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_181: " + tmpNStr_f;
				} else if (i == k_Num) {
					tmpNStr_f = S1_ini1 + "0000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_183: " + tmpNStr_f+", i="+i+", k_Num="+k_Num;
				} else if (tmpStrNp1.equals("천") || tmpStrNp2.equals("천")) { // + tmpStrNp2
					// 만천명이다:ok180428
					tmpNStr_f = S1_ini1 + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_185: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("백") || tmpStrNp2.equals("백")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_187: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("십") || tmpStrNp2.equals("십")) { // + tmpStrNp2
					// 만십명이다: ok180418
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_191: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("열") || tmpStrNp1.equals("쉰") || tmpStrNp1.equals("스물")
					|| tmpStrNp1.equals("서른") || tmpStrNp1.equals("마흔") || tmpStrNp1.equals("시흔")
					|| tmpStrNp1.equals("예순") || tmpStrNp1.equals("일흔") || tmpStrNp1.equals("여든")
					|| tmpStrNp1.equals("아흔")) {
					// 백서른살입니다 : ok180428
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum_193: " + tmpNStr_f;
					// } else if (tmpStrNp1.equals(
				} else if (tmpStrNp1.equals("스무") || tmpStrNp1.equals("설흔")) { //cy230904Ap
					tmpNStr_f = S1_ini1 + "00"+ tmpNStr_f; //
					tpRepo = tpRepo + " : fKStrNum_194/" + tmpNStr_f;	
				} else { // 만2000원이다: ok180428
					tmpNStr_f = S1_ini1 + NCu.fLeftN("000", 4 - tmpStrNp1.length()) + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum_195: " + tmpNStr_f;
				}
			} else if (S1.equals("억")) {
				if (i == 1 || tmpStrN_m1.equals("경") || tmpStrN_m1.equals("조")) {
					S1_ini1 = "1";
				} else
					S1_ini1 = "";
				/////
				if (k_Num == 1) {
					tmpNStr_f = "100000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_201: " + tmpNStr_f;
				} else if (i == k_Num) {
					// 삼억명이다 ok180428
					tmpNStr_f = S1_ini1 + "00000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_203: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("천만") || (tmpStrNp2 + tmpStrNp3).equals("천만")) {
					// y170922 억천만원이다:ok180428
					tmpNStr_f = S1_ini1 + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_205: " + tmpNStr_f;
					// } else if ((tmpStrNp1+ tmpStrNp2).equals("백만") || (tmpStrNp2+
					// tmpStrNp3).equals("백만")) {
				} else if ((tmpStrNp1 + tmpStrNp2).equals("백만") || (tmpStrNp2 + tmpStrNp3).equals("백만")) {
					// y70922일억백만원이다:ok180428
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_211: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("십만") || (tmpStrNp2 + tmpStrNp3).equals("십만")) {
					// y70922일억십만원이다: ok180428
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_213: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("만") || tmpStrNp2.equals("만")) { // + tmpStrNp2
					// 7억2000만원이다:ok180428
					if (tmpStrNp2.equals("만")) {
						tmpNStr_f = S1_ini1 + NCu.fLeftN("000", 4 - tmpStrNp1.length()) + tmpNStr_f;
					} else
						tmpNStr_f = S1_ini1 + "000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_217: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("천") || tmpStrNp2.equals("천")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + "0000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_221: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("백") || tmpStrNp2.equals("백")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + "00000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_223: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("십") || tmpStrNp2.equals("십")) { // + tmpStrNp2
					// 삼억십명이다:ok180428
					tmpNStr_f = S1_ini1 + "000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_225: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("열") || tmpStrNp1.equals("쉰") || tmpStrNp1.equals("스물")
					|| tmpStrNp1.equals("서른") || tmpStrNp1.equals("마흔") || tmpStrNp1.equals("시흔")
					|| tmpStrNp1.equals("예순") || tmpStrNp1.equals("일흔") || tmpStrNp1.equals("여든")
					|| tmpStrNp1.equals("아흔")) {
					// 백서른살입니다: ok180428
					tmpNStr_f = S1_ini1 + "000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_233: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("스무") || tmpStrNp1.equals("설흔")) { //cy230904Ap
					tmpNStr_f = S1_ini1 + "000000"+ tmpNStr_f; //
					tpRepo = tpRepo + " : fKStrNum_억_234/" + tmpNStr_f;	
				} else {
					tmpNStr_f = S1_ini1 + NCu.fLeftN("0000000", 8 - tmpStrNp1.length()) + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 억_235: " + tmpNStr_f;
				}
			} else if (S1.equals("조")) { // (trillion)
				if (i == 1 || tmpStrN_m1.equals("경")) {// || tmpStrN_m1.equals("조")
					S1_ini1 = "1";
				} else
					S1_ini1 = "";
				//
				if (k_Num == 1) {
					tmpNStr_f = "1000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_251: " + tmpNStr_f;
				} else if (i == k_Num) { // 삼조명이다:ok180428
					tmpNStr_f = S1_ini1 + "000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_253: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("천억") || (tmpStrNp2 + tmpStrNp3).equals("천억")) {
					// y170922 삼조일억원이다
					tmpNStr_f = S1_ini1 + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_255: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("백억") || (tmpStrNp2 + tmpStrNp3).equals("백억")) {
					// y70922일억백만원이다
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum 조_257: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("십억") || (tmpStrNp2 + tmpStrNp3).equals("십억")) {
					// y70922일억십만원이다
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_259: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("억") || tmpStrNp2.equals("억")) { // + tmpStrNp2
					if (tmpStrNp2.equals("억")) {
						tmpNStr_f = S1_ini1 + NCu.fLeftN("000", 4 - tmpStrNp1.length()) + tmpNStr_f;
					} else
						tmpNStr_f = S1_ini1 + "000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_261: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("천만") || (tmpStrNp2 + tmpStrNp3).equals("천만")) {
					// y170922 조천만원이다
					tmpNStr_f = S1_ini1 + "0000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_263: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("백만") || (tmpStrNp2 + tmpStrNp3).equals("백만")) {
					// y70922일억백만원이다
					tmpNStr_f = S1_ini1 + "00000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_265: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("십만") || (tmpStrNp2 + tmpStrNp3).equals("십만")) {
					// y70922일억십만원이다
					tmpNStr_f = S1_ini1 + "000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_267: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("만") || tmpStrNp2.equals("만")) { // + tmpStrNp2
					// 7조4만원이다:ok180428
					if (tmpStrNp2.equals("만")) {
						tmpNStr_f = S1_ini1 + NCu.fLeftN("0000000", 8 - tmpStrNp1.length()) + tmpNStr_f;
					} else
						tmpNStr_f = S1_ini1 + "0000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_269: " + tmpNStr_f+", tmpStrNp1="+tmpStrNp1;
				} else if (tmpStrNp1.equals("천") || tmpStrNp2.equals("천")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + "00000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_271: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("백") || tmpStrNp2.equals("백")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + "000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_273: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("십") || tmpStrNp2.equals("십")) { // ok180428:조십명이다//+ tmpStrNp2
					tmpNStr_f = S1_ini1 + "0000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_275: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("열") || tmpStrNp1.equals("쉰") || tmpStrNp1.equals("스물")
					|| tmpStrNp1.equals("서른") || tmpStrNp1.equals("마흔") || tmpStrNp1.equals("시흔")
					|| tmpStrNp1.equals("예순") || tmpStrNp1.equals("일흔") || tmpStrNp1.equals("여든")
					|| tmpStrNp1.equals("아흔")) {
					tmpNStr_f = S1_ini1 + "0000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_277: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("스무") || tmpStrNp1.equals("설흔")) {
					tmpNStr_f = S1_ini1 + "0000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_278: " + tmpNStr_f;		
				} else {
					tmpNStr_f = S1_ini1 + NCu.fLeftN("00000000000", 12 - tmpStrNp1.length()) + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_279: " + tmpNStr_f;
				}
				
			//////////////////////////////////////////////////////////////////////
			} else if (S1.equals("경")) { // (trillion)
				if (i == 1 || tmpStrN_m1.equals("해")) {// || tmpStrN_m1.equals("조")
					S1_ini1 = "1";
				} else
					S1_ini1 = "";
				//
				if (k_Num == 1) {
					tmpNStr_f = "10000000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_51: " + tmpNStr_f;
				} else if (i == k_Num) { // 삼조명이다:ok180428
					tmpNStr_f = S1_ini1 + "0000000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_53: " + tmpNStr_f;
				/////////////////////////////	
				} else if ((tmpStrNp1 + tmpStrNp2).equals("천조") || (tmpStrNp2 + tmpStrNp3).equals("천조")) {
					// y170922 삼조일억원이다
					tmpNStr_f = S1_ini1 + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_155: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("백조") || (tmpStrNp2 + tmpStrNp3).equals("백조")) {
					tmpNStr_f = S1_ini1 + "0" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum 경_157: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("십조") || (tmpStrNp2 + tmpStrNp3).equals("십조")) {
					tmpNStr_f = S1_ini1 + "00" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_159: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("조") || tmpStrNp2.equals("조")) { // + tmpStrNp2
					if (tmpStrNp2.equals("조")) {
						tmpNStr_f = S1_ini1 + NCu.fLeftN("000", 4 - tmpStrNp1.length()) + tmpNStr_f;
					} else
						tmpNStr_f = S1_ini1 + "000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_161: " + tmpNStr_f+", tmpStrNp1="+tmpStrNp1;
				///////////////////////////////////0000	///////////////////////////////////
				} else if ((tmpStrNp1 + tmpStrNp2).equals("천억") || (tmpStrNp2 + tmpStrNp3).equals("천억")) {
					// y170922 삼조일억원이다
					tmpNStr_f = S1_ini1 + "0000"+ tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_255: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("백억") || (tmpStrNp2 + tmpStrNp3).equals("백억")) {
					// y70922일억백만원이다
					tmpNStr_f = S1_ini1 + "00000" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum 경_257: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("십억") || (tmpStrNp2 + tmpStrNp3).equals("십억")) {
					// y70922일억십만원이다
					tmpNStr_f = S1_ini1 + "000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_259: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("억") || tmpStrNp2.equals("억")) { // + tmpStrNp2
					if (tmpStrNp2.equals("억")) {  //4 ->8
						tmpNStr_f = S1_ini1 + NCu.fLeftN("0000000", 8 - tmpStrNp1.length()) + tmpNStr_f;
					} else
						tmpNStr_f = S1_ini1 + "0000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_261: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("천만") || (tmpStrNp2 + tmpStrNp3).equals("천만")) {
					// y170922 조천만원이다
					tmpNStr_f = S1_ini1 + "00000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_263: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("백만") || (tmpStrNp2 + tmpStrNp3).equals("백만")) {
					// y70922일억백만원이다
					tmpNStr_f = S1_ini1 + "000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_265: " + tmpNStr_f;
				} else if ((tmpStrNp1 + tmpStrNp2).equals("십만") || (tmpStrNp2 + tmpStrNp3).equals("십만")) {
					// y70922일억십만원이다
					tmpNStr_f = S1_ini1 + "0000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 조_267: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("만") || tmpStrNp2.equals("만")) { // + tmpStrNp2
					if (tmpStrNp2.equals("만")) {   //8 ->12
						tmpNStr_f = S1_ini1 + NCu.fLeftN("00000000000", 12 - tmpStrNp1.length()) + tmpNStr_f;
					} else
						tmpNStr_f = S1_ini1 + "00000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_269: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("천") || tmpStrNp2.equals("천")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + "000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_271: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("백") || tmpStrNp2.equals("백")) { // + tmpStrNp2
					tmpNStr_f = S1_ini1 + "0000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_273: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("십") || tmpStrNp2.equals("십")) { // ok180428:조십명이다//+ tmpStrNp2
					tmpNStr_f = S1_ini1 + "00000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_275: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("열") || tmpStrNp1.equals("쉰") || tmpStrNp1.equals("스물")
					|| tmpStrNp1.equals("서른") || tmpStrNp1.equals("마흔") || tmpStrNp1.equals("시흔")
					|| tmpStrNp1.equals("예순") || tmpStrNp1.equals("일흔") || tmpStrNp1.equals("여든")
					|| tmpStrNp1.equals("아흔")) {
					// 백서른살입니다
					tmpNStr_f = S1_ini1 + "00000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_277: " + tmpNStr_f;
				} else if (tmpStrNp1.equals("스무") || tmpStrNp1.equals("설흔")) {
					tmpNStr_f = S1_ini1 + "00000000000000" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_278: " + tmpNStr_f;
				} else {   //12 ->16
					tmpNStr_f = S1_ini1 + NCu.fLeftN("000000000000000", 16 - tmpStrNp1.length()) + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 경_279: " + tmpNStr_f;
				}	

				///////////////////////////////////////////////////////////////////////////////	
			} else if (S1.equals("둘")) {
				tmpNStr_f = "2" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_361: " + tmpNStr_f;
			} else if (S1.equals("셋")) {
				tmpNStr_f = "3" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_371: " + tmpNStr_f;
			} else if (S1.equals("넷")) {
				tmpNStr_f = "4" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_381: " + tmpNStr_f;
			} else if (S1.equals("열")) {
				S1_ini1 = "1";
				//
				if (i == k_Num) { // tmpLengN=1
					tmpNStr_f = "10" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 열_401 : " + tmpNStr_f;
				} else if (i == k_Num - 1) { // tmpLengN=2
					tmpNStr_f = "1" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 열_403 : " + tmpNStr_f;
				} else
					tpRepo = tpRepo + " 검토:fKStrNum 열_415 : " + tmpNStr_f;
			} else if (S1.equals("쉰")) {
				if (i == k_Num) { // tmpStrNp1.equals("
					tmpNStr_f = "50" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 쉰_422: " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tmpNStr_f = "5" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 쉰_425: " + tmpNStr_f;
				} else
					tpRepo = tpRepo + " 검토:fKStrNum 열_427 : " + tmpNStr_f;
			} else if (S2.equals("하나")) {
				tmpNStr_f = "1" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum 하나_431 : " + tmpNStr_f;
			} else if (S2.equals("다섯")) {
				tmpNStr_f = "5" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum 다섯_441 :" + tmpNStr_f;
			} else if (S2.equals("여섯")) {
				tmpNStr_f = "6" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum 여섯_451 :" + tmpNStr_f;
			} else if (S2.equals("일곱")) {
				tmpNStr_f = "7" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum 일곱_461 :" + tmpNStr_f;
			} else if (S2.equals("여덟")) {
				tmpNStr_f = "8" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum 여덟_471 :" + tmpNStr_f;
			} else if (S2.equals("아홉")) {
				tmpNStr_f = "9" + tmpNStr_f;
				tpRepo = tpRepo + " :fKStrNum 아홉_481 :" + tmpNStr_f;
			} else if (S2.equals("스물")) {
				if (i == k_Num) {
					tmpNStr_f = "20" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum 스물_501 :" + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tmpNStr_f = "2" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 스물_511 : " + tmpNStr_f;
				}
			} else if (S2.equals("스무")) { 
				if (i == k_Num) {
					tmpNStr_f = "20" + tmpNStr_f;
					tpRepo = tpRepo + " :fKStrNum 스무_502 :" + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tmpNStr_f = "2" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 스무_512 : " + tmpNStr_f;
				}	
			} else if (S2.equals("서른") || S2.equals("설흔")) { // ok:180428:나이는 서른살이다
				if (i == k_Num) {
					tmpNStr_f = "30" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 서른_531: " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tmpNStr_f = "3" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 서른_535: " + tmpNStr_f;
				}
			} else if (S2.equals("마흔")) {
				if (i == k_Num) {
					tmpNStr_f = "40" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 마흔_551: " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tpRepo = tpRepo + " : fKStrNum 마흔_555: " + tmpNStr_f;
					tmpNStr_f = "4" + tmpNStr_f;
				}
			} else if (S2.equals("시흔")) {
				if (i == k_Num) {
					tmpNStr_f = "50" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 시흔_581: " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tmpNStr_f = "5" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 시흔_585: " + tmpNStr_f;
				}
			} else if (S2.equals("예순")) {
				// if tmpStrNp1.equals(" then
				if (i == k_Num) {
					tmpNStr_f = "60" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 예순_601: " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tpRepo = tpRepo + " : fKStrNum 예순_605: " + tmpNStr_f;
					tmpNStr_f = "6" + tmpNStr_f;
				}
			} else if (S2.equals("일흔")) { // if tmpStrNp1.equals(" then
				if (i == k_Num) {
					tmpNStr_f = "70" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 일흔_621: " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tmpNStr_f = "7" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 일흔_625: " + tmpNStr_f;
				}
			} else if (S2.equals("여든")) {
				if (i == k_Num) {
					tmpNStr_f = "80" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 여든_641: " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tmpNStr_f = "8" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 여든_645: " + tmpNStr_f;
				}
			} else if (S2.equals("아흔")) {
				if (i == k_Num) {
					tmpNStr_f = "90" + tmpNStr_f;
					tpRepo = tpRepo + " : fKStrNum 아흔661 : " + tmpNStr_f;
				} else if (i == k_Num - 1) {
					tpRepo = tpRepo + " : fKStrNum 아흔_665 : " + tmpNStr_f;
					tmpNStr_f = "9" + tmpNStr_f;
				}
			} else if (S1.equals("한")) {
				tmpNStr_f = "1" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_721 : " + tmpNStr_f;
			} else if (S1.equals("두")) { // if tmpLengN=1 then
				tmpNStr_f = "2" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_725 : " + tmpNStr_f;
			} else if (S1.equals("세")) {
				tmpNStr_f = "3" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_731 : " + tmpNStr_f;
			} else if (S1.equals("네")) {
				tmpNStr_f = "4" + tmpNStr_f;
				tpRepo = tpRepo + " : fKStrNum_734 : " + tmpNStr_f;
			} else
				tpRepo = tpRepo + " : fPickKStrNum 검토_883: " + tmpNStr_f + " fKStrNumb check Unexpected Num";
		} // for i = downto 1
		// 
		tmpResu = NCu.fRightN("0000" + i_StrNumf, 4); 
		System.out.println("Efn_fPKSNum_S9999 i_StrNumf="+i_StrNumf+", tmStrNum1=" + tmStrNum1 + ", tmpNStr_f="
			+ tmpNStr_f +", tpRepo=" + tpRepo);
		//return reAr4StrNum;
		if (tmpResu.equals("0000")) {
			return "";
		} else
			return tmpResu + tmpNStr_f;
	} //fPickKStrNumer _fin
	
	public static String fPickKStrDotNum(String tmiEjeol, String tmEjeol_m1, String tmStr1) {	//int tmi,
		int tl_Ejlth = tmStr1.length(), k_Num = 0, i_StrNumf = 0;
		String tmpResu = "", S1 = "", S2 = "", tmpNStr_f = ""; //tmpStrN = "",  S1_ini1="",
		String  tpS1p1="", tmpS2p1="", tpRepo = "";	//tmpS1m1="",
		boolean tfNumBf = false;
		//
		String[] teStrNum = new String[40];
		teStrNum[0] = ""; // ok:180428:일억백만원이다
		boolean[] tfA1Num = new boolean[40];
		// for (int i=0; i<tl_Ejlth; i++) {
		int i = 0;
		while (i < tl_Ejlth) {
			//tmpS1m1= S1;
			//System.out.println("ck_KStr_00 i="+i+", tl_Ejlth="+tl_Ejlth+", tmpS1m1="+tmpS1m1+", S1="+S1+", tmiEjeol="+tmiEjeol+", tmStr1="+tmStr1);
			S1 = tmStr1.substring(i, i + 1);
			
			tpS1p1 = "";
			tmpS2p1 = "";
			if (i < tl_Ejlth - 1) {
				tpS1p1 = tmStr1.substring(i + 1, i + 2); // 너의 나이는 열두살이다 //참조: (Copy(tmpStr1,i+2,2)='살')
				if (i < tl_Ejlth - 2)
					tmpS2p1 = tmStr1.substring(i + 1, i + 3); //
			}
			///
			S2 = "";
			if (i < tl_Ejlth - 1)  //cyEd:201210:
				S2 = S1 + tpS1p1; //tmStr1.substring(i + 1, i + 2);
			///
			if (i>37) {
				System.out.println("자릿수가 38이어서 중단합니다. k_Num="+k_Num+", i="+i+" , tpS1p1="+tpS1p1);	//+", tmpStrN="+tmpStrN
				break;
			} else if (S1.length() > 0) {
				if (S2.equals("하나") || S2.equals("다섯") || S2.equals("여섯") || S2.equals("일곱") || S2.equals("여덟")
					|| S2.equals("아홉")) {
					k_Num = k_Num + 1;
					teStrNum[k_Num] = S2;
					i_StrNumf = i_StrNumf + 2;
					tfNumBf = false;
					tfA1Num[k_Num] = false;
					i++; // cy180428://S2TF=true;
					tpRepo = tpRepo + " : pre_fnPickKSDotN_1"; //  tmpStrN=" + tmpStrN;
				} else if (S1.equals("이")) {
					if (tpS1p1.equals("다") || tpS1p1.equals("냐") || tpS1p1.equals("었")) {
						tpRepo = tpRepo + " : pre_fPKSDotN_2"; // tmpStrN=" + tmpStrN;
						break;
					} else {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fnPKSDotN_4"; // tmpStrN=" + tmpStrN;
					}
				} else if (S1.equals("사")) {
					if (tmpS2p1.equals("나이")) {
					} else {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfNumBf = false;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fnPKSDotN_5a"; //  tmpStrN=" + tmpStrN;
					}
				} else if (S1.equals("삼") ||  S1.equals("오") || S1.equals("육") || S1.equals("칠")
					|| S1.equals("팔") || S1.equals("구") || S1.equals("둘") || S1.equals("셋") || S1.equals("넷")
					|| S1.equals("공") || S1.equals("영")) {
					k_Num = k_Num + 1;
					teStrNum[k_Num] = S1;
					i_StrNumf = i_StrNumf + 1;
					//tmpStrN = tmpStrN + S1;
					tfNumBf = false;
					tfA1Num[k_Num] = false;
					tpRepo = tpRepo + " : pre_fnPKSDotN_5"; //  tmpStrN=" + tmpStrN;
					// ok: System.out.println("tpRepo="+tpRepo);
				} else if (S1.equals("일")) {
					if (NCu.fRightN(tmEjeol_m1, 1).equals("월") && tpS1p1.equals("일")) { //mEjeolm1
						break;
					} else if (teStrNum[k_Num].equals("한") || teStrNum[k_Num].equals("두")
						|| teStrNum[k_Num].equals("세")) {
						tpRepo = tpRepo + " : pre_fPKSDotN_3"; // tmpStrN=" + tmpStrN;
						break;
					} else {
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tpRepo = tpRepo + " : pre_fPKSDotN_9"; // tmpStrN=" + tmpStrN;
					}
					tfNumBf = false;
					tfA1Num[k_Num] = false;
					// }else if (S1.equals("세")) {
				} else if (S1.equals("한") || S1.equals("두") || S1.equals("세") || S1.equals("네")) {
					if (tpS1p1.equals("달") || tpS1p1.equals("살") || tpS1p1.equals("명") || tmpS2p1.equals("마리")
						|| tmpS2p1.equals("군데")) { //
						k_Num = k_Num + 1;
						teStrNum[k_Num] = S1;
						i_StrNumf = i_StrNumf + 1;
						tfA1Num[k_Num] = false;
						tpRepo = tpRepo + " : pre_fPKSDotN_11 tpS1p1=" + tpS1p1; //+ ", tmpStrN=" + tmpStrN;
					} else {
						tpRepo = tpRepo + " : pre_fPKSDotN_13 tpS1p1=" + tpS1p1 + ", tmpS2p1=" + tmpS2p1; // + ", tmpStrN="+ tmpStrN;
						break;
					}
					tfNumBf = false;
				} else if (S1.equals("1") || S1.equals("2") || S1.equals("3") || S1.equals("4") || S1.equals("5")
						|| S1.equals("6") || S1.equals("7") || S1.equals("8") || S1.equals("9") || S1.equals("0")) {
					if (tfNumBf == false) {
						k_Num = k_Num + 1;
						tfNumBf = true;
						teStrNum[k_Num] = S1;
					} else
						teStrNum[k_Num] = teStrNum[k_Num] + S1;
					//
					i_StrNumf = i_StrNumf + 1;
					tfA1Num[k_Num] = true;
					tpRepo = tpRepo + " : pre_fPKSDotN_15 tpS1p1=" + tpS1p1 ; //+ ", tmpStrN=" + tmpStrN;
				} else {
					tpRepo = tpRepo + " : pre_fPKSDotN_17 tpS1p1=" + tpS1p1 ; //+ ", tmpStrN=" + tmpStrN;
					break;
				}
			} // if (S1.length()>0)

			i++;
		} // while
			///////////////////////////////////////////////
		tmpNStr_f = "";
		for (i = k_Num; i >= 1; i--) { //// for i = k_Num downto 1 do
			S1 = "";
			S2 = "";
			//
			if (tfA1Num[i]) {
				tmpResu = "TTrue";
			} else
				tmpResu = "FFalse";
			//
			if (tfA1Num[i] == true) {
				S1 = teStrNum[i];
			} else if (teStrNum[i].length() == 1) {
				S1 = teStrNum[i];
			} else if (teStrNum[i].length() == 2)
				S2 = teStrNum[i];
			//
			if (tfA1Num[i] == true) {
				tmpNStr_f = S1 + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_11 " + tmpNStr_f + ", tmpNStr_f=" + tmpNStr_f;
			} else if (S1.equals("일")) { // 검토: 이십일일이다
				tpS1p1 = NCu.fCopyN(tmiEjeol, S1.length() + 1, 1); 
				if (NCu.fRightN(tmEjeol_m1, 1).equals("월") && tpS1p1.equals("일")) { //
					tpRepo = tpRepo + " :fPKSDotN_23 " + tmpNStr_f;
				} else {
					tmpNStr_f = "1" + tmpNStr_f;
					tpRepo = tpRepo + " : fPKSDotN_25 /" + tmpNStr_f;
				}
			} else if (S1.equals("이")) {
				tmpNStr_f = "2" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_27 /" + tmpNStr_f;
			} else if (S1.equals("삼")) {
				tmpNStr_f = "3" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_29 /" + tmpNStr_f;
			} else if (S1.equals("사")) {
				tmpNStr_f = "4" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_31 /" + tmpNStr_f;
			} else if (S1.equals("오")) {
				tmpNStr_f = "5" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_33 /" + tmpNStr_f;
			} else if (S1.equals("육")) {
				tmpNStr_f = "6" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_35 /" + tmpNStr_f;
			} else if (S1.equals("칠")) {
				tmpNStr_f = "7" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_37 /" + tmpNStr_f;
			} else if (S1.equals("팔")) {
				tmpNStr_f = "8" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_39 /" + tmpNStr_f;
			} else if (S1.equals("구")) {
				tmpNStr_f = "9" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_41 /" + tmpNStr_f;
			} else if (S1.equals("공") || S1.equals("영")) {
				tmpNStr_f = "0" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_43 공/영_00 /" + tmpNStr_f;
			} else if (S1.equals("둘")) {
				tmpNStr_f = "2" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_55 /" + tmpNStr_f;
			} else if (S1.equals("셋")) {
				tmpNStr_f = "3" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_57 /" + tmpNStr_f;
			} else if (S1.equals("넷")) {
				tmpNStr_f = "4" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_59 /" + tmpNStr_f;
			} else if (S2.equals("하나")) {
				tmpNStr_f = "1" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_71 / " + tmpNStr_f;
			} else if (S2.equals("다섯")) {
				tmpNStr_f = "5" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_73 /" + tmpNStr_f;
			} else if (S2.equals("여섯")) {
				tmpNStr_f = "6" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_75 /" + tmpNStr_f;
			} else if (S2.equals("일곱")) {
				tmpNStr_f = "7" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_77 /" + tmpNStr_f;
			} else if (S2.equals("여덟")) {
				tmpNStr_f = "8" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_79 /" + tmpNStr_f;
			} else if (S2.equals("아홉")) {
				tmpNStr_f = "9" + tmpNStr_f;
				tpRepo = tpRepo + " :fPKSDotN_81 /" + tmpNStr_f;
			} else if (S1.equals("한")) {
				tmpNStr_f = "1" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_91 /" + tmpNStr_f;
			} else if (S1.equals("두")) { 
				tmpNStr_f = "2" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_93 /" + tmpNStr_f;
			} else if (S1.equals("세")) {
				tmpNStr_f = "3" + tmpNStr_f;
				tpRepo = tpRepo + " : fPKSDotN_95 /" + tmpNStr_f;
			} else
				tpRepo = tpRepo + " : fPKSDotN_98 검토/" + tmpNStr_f + " fPKSNumb check Unexpected Num";
		} // for i = downto 1
			///
		tmpResu = NCu.fRightN("0000" + i_StrNumf, 4); 
		//////
		//##//System.out.println("Cuti_bu00U fPKSDotN_999 return=" + tmpResu + tmpNStr_f + ", tmStr1=" + tmStr1 + ", tmpNStr_f="
		//##//	+ tmpNStr_f + ", S2=" + S2 + ", tpRepo=" + tpRepo);
		if (tmpResu.equals("0000")) {
			return "";
		} else
			return tmpResu + tmpNStr_f;
	} //fPickKStrDotNum
}
