package nuCtrl;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import nuBus.NuBus2;


@WebServlet("/NuServlet")
public class NuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	NuBus2 nuBus2;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		String Text1 = request.getParameter("userText");
		response.getWriter().write(getJSON(Text1));
	}	
		
	public String getJSON(String userText1) {
		nuBus2 = new NuBus2();
		String tpAns_f1 = nuBus2.fBuNumer(userText1);
		return tpAns_f1; 
	}
}
