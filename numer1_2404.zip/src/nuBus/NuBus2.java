package nuBus;

import cuti.NCu;
import nuEfn.NEfn;

//import sel.Rsel;

public class NuBus2 {
	//EfMet1 efMet1;
	private static int mmk_Ejeol;
	private static String[] mEjeol = new String[99];
	private static String[] mEjeol_f = new String[99];
	
	public static String fBuNumer(String tmUserText1) {
		//StringBuffer sb_Ans= new StringBuffer();
		String tpAText1= tmUserText1.trim();
		String teEjeol_f="";
		//String tpAnswer= "";
		
		mEjeol= NEfn.be00Ejl_kArray1(tpAText1);
		mmk_Ejeol=Integer.parseInt(mEjeol[0]);
		
		int jLen= 0;
		String teEjKSNum_0= "", teEjKSNum= "", teEjKSNum_B= "";
		for (int i=1; i<=mmk_Ejeol; i++) {
			teEjKSNum_0 = NEfn.fPickKStrNumber(mEjeol[i], mEjeol[i-1], mEjeol[i]);
			teEjeol_f= mEjeol[i];
			if (teEjKSNum_0.length() > 0) {
				jLen = Integer.parseInt(NCu.fLeftN(teEjKSNum_0, 4));
				teEjKSNum = NCu.fCopyF(teEjKSNum_0, 5);
				teEjKSNum_B = NCu.fCopyF(mEjeol[i], jLen + 1);
				teEjeol_f= teEjKSNum+ teEjKSNum_B;	//mEjeol_f[i]
			}
			mEjeol_f[i]= teEjeol_f;
		}
		
		////////////////////
		//tpAnswer= sb_Ans.toString();

		String tpAnswer_f= mEjeol_f[1];
		if (mmk_Ejeol>1)
		for (int i=2; i<=mmk_Ejeol; i++) {
			tpAnswer_f+= " "+ mEjeol_f[i];
		}

		
		if (tpAnswer_f.length()==0) {
			tpAnswer_f= "내용이 없습니다!";
		}
		
		////////////
		return tpAnswer_f;
	}
}
