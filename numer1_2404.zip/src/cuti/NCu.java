package cuti;

import nuEfn.NEfn;

public class NCu {
	public static String fPickRMarkStrAll(String tmStr1) {
		char chMark = 0;
		String teResu = "";
		String teMarkS1 = "";
		//
		if (tmStr1 != null && tmStr1.length() > 0)
			for (int i = tmStr1.length() - 1; i >= 0; i--) { // downto -1, i>=0; rrr
				chMark = tmStr1.charAt(i);
				if (chMark != 0)
					teMarkS1 = NEfn.fPick1ChMarkAsS1(chMark);
				///
				if (teMarkS1.length() == 0) {
					break;
				} else {
					teResu = teMarkS1 + teResu;
				}
			}
		return teResu;
	}
	
	public static boolean ftfOneNumber(String tmStr1) {
		boolean tf_Number = false;
		if (tmStr1.length() == 1) {
			char ch = tmStr1.charAt(0);
			if (ch >= '0' && ch <= '9') {
				tf_Number = true;
			} else
				tf_Number = false;
		} else
			tf_Number = false;
		return tf_Number;
	}
	
	public static String fCopyF(String str1, int i1) {
		String teResu="";
		if (str1!=null && str1.length()>0) {
			if (i1>0 && str1.length()>=i1)
				teResu= str1.substring(i1-1);
		}
		return teResu;
	}
	
	public static String fCopyN(String str1, int i1, int cn) {
		String teResu="";
		if (str1!=null && str1.length()>0) {
			if (i1>0 && cn>0 && str1.length()>=i1+cn-1)
				teResu= str1.substring(i1-1,i1+cn-1);
		}	
		return teResu;
	}
	
	public static String fLeftN(String str1, int lLen) {
	    String teResu="";
	    if (str1!=null && lLen>0)
	    	if (str1.length()>=lLen)
	    		teResu = str1.substring(0,lLen); 
		return teResu;	
	}
	
	public static String fRightN(String str1, int rLen) {
	    String teResu="";
	    if (str1!=null && rLen>0)
	    	if (str1.length()>=rLen)
	    		teResu = str1.substring(str1.length()-rLen);
		return teResu;	
	}
	
	public static String ltrim(String str1) {
		char[] cval = str1.toCharArray();
		int i_st = 0;
		int len = str1.length();
		while (i_st < len && cval[i_st] <= ' ') {
			i_st++;
		}
		return str1.substring(i_st, len);
	}

	public static String rtrim(String str1) {
		char[] cval = str1.toCharArray();
		int i_st = 0;
		int len = str1.length();
		while (i_st < len && cval[len - 1] <= ' ') {
			len--;
		}
		return str1.substring(0, len);
	}
}
